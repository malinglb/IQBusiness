package za.messager01.exception;
/* 
 * ExceptionHandler is the custom exception handling class to be invoked in to your service
 * ExceptionHandler extends RuntimeException interface
 * */
public class ExceptionHandler extends RuntimeException {

	private static final long serialVersionUID = 1L;

	//The constructor takes in the error message Str and calls the Parent/Superclass
	public ExceptionHandler(String message) {
		super(message);
	}

	
}
