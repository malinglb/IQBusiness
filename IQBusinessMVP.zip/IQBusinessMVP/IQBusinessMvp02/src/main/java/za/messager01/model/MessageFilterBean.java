package za.messager01.model;

import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;

public class MessageFilterBean {
	
	@QueryParam("year") private int year; 
	@QueryParam("start") private int start;
	@QueryParam("size") private int size;
	@QueryParam("profileName") private String profileName;
	@QueryParam("messagerId") long messagerId;
	
	
	public long getMessagerId() {
		return messagerId;
	}
	public void setMessagerId(long messagerId) {
		this.messagerId = messagerId;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public String getProfileName() {
		return profileName;
	}
	public void setProfileName(String profileName) {
		this.profileName = profileName;
	}
	
	

}
