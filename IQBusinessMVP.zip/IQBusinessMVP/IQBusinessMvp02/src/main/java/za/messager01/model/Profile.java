package za.messager01.model;

import java.util.*;

import javax.xml.bind.annotation.XmlTransient;

/*
 * STEP 1: Create necessary model class for your resource.
 * STEP 2: Ensure model class have a no-argument constructor.
 * Annotate the model class with @XmlRootElement to parse to Xml content type if necessary
 *  */

public class Profile {
	private long id;
	private String ProfileName;
	private String firstName;
	private String lastName;
	private String said;
	private Date created;
	private Map<Long, Message> messages = new HashMap<>();
	private List<Link> links = new ArrayList<>();
	
	
	public Profile() {
		super();
	}
	public Profile(long id, String profileName, String firstName, String lastName,String said) {
		super();
		this.id = id;
		this.ProfileName = profileName;
		this.firstName = firstName;
		this.lastName = lastName;
		this.said = said;
		this.created = new Date();
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	public String getSaid() {
		return said;
	}
	public void setSaid(String said) {
		this.said = said;
	}
	public String getProfileName() {
		return ProfileName;
	}
	public void setProfileName(String profileName) {
		ProfileName = profileName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	@XmlTransient
	public Map<Long, Message> getMessages() {
		return messages;
	}
	public void setMessages(Map<Long, Message> messages) {
		this.messages = messages;
	}
	public List<Link> getLinks() {
		return links;
	}
	public void setLinks(List<Link> links) {
		this.links = links;
	}
	public void addLink(String url, String rel) {
		Link link = new Link();
		link.setLink(url);
		link.setRel(rel);
		links.add(link);
	}
	

}
