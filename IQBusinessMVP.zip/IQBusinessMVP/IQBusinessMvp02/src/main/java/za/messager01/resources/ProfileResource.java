package za.messager01.resources;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriInfo;

import za.messager01.model.ErrorMessage;
import za.messager01.model.Profile;
import za.messager01.service.ProfileService;

/**
 * ProfileResource is a root resource within the messager01 application with a delegation stub for message resource
 */
@Path("profiles")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class ProfileResource {
	ProfileService profileService = new ProfileService();

	/*
	 * Stub getProfiles get profiles
	 * Instance URI http://localhost:8080/IQBusinessMvp02/webapi/profiles
	 */
	@GET
	public List<Profile> getProfiles() {
		return profileService.retrieveProfiles();
	}

	/*
	 * Stub getProfile get profile by profileName (Positive scenario)
	 * Instance URI http://localhost:8080/IQBusinessMvp02/webapi/profiles/Lmalinga
	 * Throws runtime custom exception to ExceptionHandler if profileName not found (Negative scenario)
	 */
	

	@GET
	@Path("/{profileName}")
	public Profile getProfile(@PathParam("profileName") String profileName,@Context UriInfo uriInfo ) {
		Profile profile = profileService.getProfile(profileName);
		
		//prepare error message response
		String uri = uriInfo.getAbsolutePathBuilder().build().toString();
		ErrorMessage errorMessage = new ErrorMessage(profileName + " Not Found", 404,uri);
		Response response = Response.status(Status.NOT_FOUND).entity(errorMessage).build();
		if(profile == null)
		{
			throw new WebApplicationException(response);
		}
		profile.addLink(getUrlForProfile(uriInfo, profile),"self");
		return profile;
	}
	private String getUrlForProfile(UriInfo uriInfo, Profile profile) {
		String url = uriInfo.getBaseUriBuilder().path(ProfileResource.class).path(profile.getProfileName()).build().toString();
		return url;
	}
	/*
	 * Stub addProfile post new profile to dbMapping
	 * Instance URI http://localhost:8080/IQBusinessMvp02/webapi/profiles
	 */
	@POST
	public Profile addProfile(Profile profile) {
		return profileService.addProfile(profile);
	}
	/*
	 * Stub updateProfile put new profile changes to dbMapping
	 * Instance URI http://localhost:8080/IQBusinessMvp02/webapi/profiles
	 */
	@PUT
	@Path("/{profileName}")
	public Profile updateProfile(@PathParam("profileName") String profileName, Profile profile) {
		profile.setProfileName(profileName);
		return profileService.updateProfile(profile);
	}
	/*
	 * Stub deleteProfile delete  profile to dbMapping
	 * Instance URI http://localhost:8080/IQBusinessMvp02/webapi/profiles
	 */
	@DELETE
	@Path("/{profileName}")
	public void deleteProfile(@PathParam("profileName") String profileName) {
		profileService.removeProfile(profileName);
	}

	/*
	 * Stub retrieveMessageResource is a delegation to a subResource
	 * Collection URI http://localhost:8080/IQBusinessMvp02/webapi/profiles/{profileName}/messages
	 */
	@Path("/{profileName}/messages")
	public MessageResource retrieveMessageResource() {
		return new MessageResource();
	}

	/*@GET
	@Path("/{profileName}")
	public Profile getProfile(@PathParam("profileName") String profileName) {
		Profile profile = profileService.getProfile(profileName);
		if(profile == null)
		{
			throw new ExceptionHandler("Message with profile "+ profileName+ " not found." );
		}
		return profile;
	}*/
}
