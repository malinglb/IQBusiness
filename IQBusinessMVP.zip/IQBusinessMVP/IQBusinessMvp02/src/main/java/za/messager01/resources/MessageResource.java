package za.messager01.resources;

import java.util.List;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriInfo;

import za.messager01.model.Message;
import za.messager01.model.MessageFilterBean;
import za.messager01.service.MessageService;

/*
 * MessageResource is a sub resource of the profile as a root resource
 * Collection URI http://localhost:8080/IQBusinessMvp02/webapi/profiles/{profileName}/messages/
 */

@Path("/")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class MessageResource {
	MessageService messageService = new MessageService();

	/*
	 * Stub getMessages returns messages based on custom filtering(per year) and
	 * pagination(per start &size) Collection URI
	 * http://localhost:8080/IQBusinessMvp02/webapi/messages?year=2014&start=30&size=10
	 * Bean Param annotation is used to point to MessageFilterBean
	 */
	@GET
	public List<Message> getMessages(@BeanParam MessageFilterBean messageFilterBean,
			@PathParam("profileName") String profileName) {
		if (messageFilterBean.getYear() > 0) {
			return messageService.getMessagesForYear(messageFilterBean.getYear(), profileName);
		}
		if (messageFilterBean.getStart() > 0 && messageFilterBean.getSize() > 0) {
			return messageService.getMessagesPaginated(messageFilterBean.getStart(), messageFilterBean.getSize(),
					profileName);
		}
		return messageService.retrieveMessages(profileName);
	}

	/*
	 * Stub getMessage get message by messageId Collection URI
	 * http://localhost:8080/IQBusinessMvp02/webapi/profiles/Lmalinga/messages
	 * Test message
	 *  {
           "message":"Test Message", 
           "created":"2020-06-01T18:06:36:902"
           "author": "Linde"
       }
	 */
	@GET
	@Path("/{messagerId}")
	public Message getMessage(@BeanParam MessageFilterBean messageFilterBean,
			@PathParam("profileName") String profileName, @Context UriInfo uriInfo) {
		Message message = messageService.getMessage(messageFilterBean.getMessagerId(), profileName);
		message.addLink(getUrlForSelf(uriInfo, message,profileName), "self");
		message.addLink(getUrlForProfile(uriInfo, message,profileName), "profile");
		return message;
	}

	private String getUrlForSelf(UriInfo uriInfo, Message message,String profileName) {
		String url = uriInfo.getBaseUriBuilder().path(ProfileResource.class).path(ProfileResource.class,"retrieveMessageResource")
				.path(Long.toString(message.getId()))
			    .resolveTemplate("profileName", profileName).build().toString();
		return url;
	}
	private String getUrlForProfile(UriInfo uriInfo, Message message,String profileName) {
		String url = uriInfo.getBaseUriBuilder().path(ProfileResource.class).path(profileName).build().toString();
		return url;
	}

	/*
	 * Stub addMessages post new message to the DBMapping Collection URI
	 * http://localhost:8080/IQBusinessMvp02/webapi/profiles/Lindelani/messages
	 */
	@POST
	public Message addMessages(Message message, @PathParam("profileName") String profileName,@Context UriInfo uriInfo) {
		Message responseMessage = messageService.addMessage(message, profileName);
		message.addLink(getUrlForSelf(uriInfo, message,profileName), "self");
		message.addLink(getUrlForProfile(uriInfo, message,profileName), "profile");
		return responseMessage;
	}

	/*
	 * Stub updateMessages update message to the DBMapping Collection URI
	 * http://localhost:8080/IQBusinessMvp02/webapi/messages
	 */
	@PUT
	public Message updateMessage(Message message, @PathParam("profileName") String profileName) {
		return messageService.updateMessage(message, profileName);
	}

	/*
	 * Stub deleteMessage delete message to the DBMapping Collection URI
	 * http://localhost:8080/IQBusinessMvp02/webapi/messages/messagerId
	 */
	@DELETE
	@Path("/{messagerId}")
	public void deleteMessage(@PathParam("messagerId") long messagerId, @PathParam("profileName") String profileName) {
		messageService.removeMessage(messagerId, profileName);
	}

	/*
	 * @GET
	 * 
	 * @Path("context") public String getParamsUsingContext(@Context UriInfo
	 * uriInfo, @Context HttpHeaders httpHeaders) { String path =
	 * uriInfo.getAbsolutePath().toString(); String cookies =
	 * httpHeaders.getCookies().toString(); return "Path: " + path +" cookies: "+
	 * cookies; }
	 */

}
