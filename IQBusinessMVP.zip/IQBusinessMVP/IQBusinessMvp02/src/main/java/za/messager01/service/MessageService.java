package za.messager01.service;

import java.util.*;

import za.messager01.db.DbMapping;
import za.messager01.model.Message;
import za.messager01.model.Profile;

/*
 * STEP 1: Create necessary service class that retrieve the response.
 * STEP 2: Create this service stubs to  call into your resource.
 *  */
public class MessageService {

	//private Map<Long, Message> messages = DbMapping.getMessages();
	private Map<String, Profile> profiles = DbMapping.getProfiles();

	/*public MessageService() {
		messages.put(1L, new Message(1L, "Welcome to common API JAX-RS!", "Linde"));
		messages.put(2L, new Message(2L, "Jersey is your referred Implement.", "Linde"));
	}*/

	public List<Message> retrieveMessages(String profileName) {

		Map<Long, Message> messages = profiles.get(profileName).getMessages();
		return new ArrayList<Message>(messages.values());
	}

	public List<Message> getMessagesForYear(int year, String profileName) {
		Map<Long, Message> messages = profiles.get(profileName).getMessages();
		List<Message> messageForYear = new ArrayList<>();
		Calendar cal = Calendar.getInstance();
		for (Message message : messages.values()) {
			cal.setTime(message.getCreated());
			if (cal.get(Calendar.YEAR) == year) {
				messageForYear.add(message);
			}
		}
		return messageForYear;
	}

	public List<Message> getMessagesPaginated(int start, int size, String profileName) {
		Map<Long, Message> messages = profiles.get(profileName).getMessages();
		List<Message> lsMessages = new ArrayList<Message>(messages.values());
		if (start + size > lsMessages.size()) {
			return new ArrayList<Message>();
		}
		return lsMessages.subList(start, start + size);
	}

	public Message getMessage(long id, String profileName) {
		Map<Long, Message> messages = profiles.get(profileName).getMessages();
		return messages.get(id);
	}

	public Message addMessage(Message message, String profileName) {
		Map<Long, Message> messages = profiles.get(profileName).getMessages();
		// Increment/generate new message id
		message.setId(messages.size() + 1);
		// Set new message in the hash list
		messages.put(message.getId(), message);
		return message;
	}

	public Message updateMessage(Message message, String profileName) {
		Map<Long, Message> messages = profiles.get(profileName).getMessages();
		if (message.getId() <= 0 && profileName.isEmpty()) {
			return null;
		}
		messages.put(message.getId(), message);
		return message;
	}

	public Message removeMessage(long id, String profileName) {
		Map<Long, Message> messages = profiles.get(profileName).getMessages();
		return messages.remove(id);
	}

}
