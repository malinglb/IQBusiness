package za.messager01.db;

import java.util.*;

import za.messager01.model.Message;
import za.messager01.model.Profile;

public class DbMapping {
	
	private static Map<Long, Message> messages = new HashMap<>();
	private static Map<String, Profile> profiles = new HashMap<>();
	
	
	public static Map<Long, Message> getMessages() {
		return messages;
	}
	public static Map<String, Profile> getProfiles() {
		return profiles;
	}
	

}
