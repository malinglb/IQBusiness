package za.messager01.exception;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import za.messager01.model.ErrorMessage;

/* 
 * Every exception mapper class implements ExceptionMapper Jax-rs a raw type 
 * ExceptionMapper must be converted to a custom/generic type your runtime exception handler cls
 * */
@Provider
public class ExceptionHandlerMapper implements ExceptionMapper<ExceptionHandler> {

	@Override
	public Response toResponse(ExceptionHandler ex) {
		ErrorMessage errorMessage = new ErrorMessage(ex.getMessage(), 404,"http://localhost:8080/Messager01/profiles");
		return Response.status(Status.NOT_FOUND).entity(errorMessage).build();
	}

}
