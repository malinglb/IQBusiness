package za.messager01.model;

import java.util.*;

import javax.xml.bind.annotation.XmlRootElement;

/*
 * STEP 1: Create necessary model class for your resource.
 * STEP 2: Ensure model class have a no-argument constructor.
 * Annotate the model class with @XmlRootElement to parse to Xml content type
 *  */
@XmlRootElement(name = "Message")
public class Message {

	private long id;
	private String message;
	private Date created;
	private String author;
	private List<Link> links = new ArrayList<>();

	public Message() {

	}

	public Message(long id, String message, String author) {
		this.id = id;
		this.message = message;
		this.created = new Date();
		this.author = author;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public List<Link> getLinks() {
		return links;
	}

	public void setLinks(List<Link> links) {
		this.links = links;
	}
	public void addLink(String url, String rel) {
		Link link = new Link();
		link.setLink(url);
		link.setRel(rel);
		links.add(link);
	}
}
