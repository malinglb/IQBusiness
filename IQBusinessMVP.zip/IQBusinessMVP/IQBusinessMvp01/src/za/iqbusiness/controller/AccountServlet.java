package za.iqbusiness.controller;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.*;

import za.iqbusiness.model.Account;

/**
 * MVC
 */
@WebServlet("/AccountServlet")
public class AccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private HttpSession hSession;
	private Logger log;

	public AccountServlet() {
		this.log = LogManager.getLogger(AccountServlet.class);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		log.info("Start logging.");
		String url = "/DisplayMenu.jsp";
		// Menu 1 input data
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");
		String country = request.getParameter("country");
		// Instantiate Account object & append country code to the msisdn
		String countryCode = retrieveCountryCode(country);
		Account account = new Account(country, countryCode, phone,email);
		account.setPhone(phone);

		// N.B Reserve application session to be used across the application instead of
		// db
		hSession = request.getSession();
		hSession.setAttribute("account", account);
		/*
		 * db account update updateDB(phone,countryCode);
		 */

		// Proceed to Menu 2
		request.setAttribute("account", account);
		getServletContext().getRequestDispatcher(url).forward(request, response);

	}

	public String retrieveCountryCode(String country) {
		String code = new String();
		try {
			code = (country.equalsIgnoreCase("kenya")) ? "+254" : "+265";

		} catch (Exception ex) {

			ex.printStackTrace();
		}

		return code;
	}

	public void updateDB(String phone, String email, String countryCode) {
		Connection myConnection = null;

		try {
			// Init JDBC
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost/IQBusinessMvp01";
			// DB Credentials
			String user = "dbadmin";
			String pword = "password1";
			// Open JDBC DB
			myConnection = DriverManager.getConnection(url, user, pword);
			Statement statement = myConnection.createStatement();
			String query = "INSERT INTO account " + "(phone,email, countrycode,accountid)" + 
			"VALUES ('" + phone + "', " + "'" + email + "',  " + "'" + countryCode + "'   , NULL)";
			// Commit into db
			statement.execute(query);

		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				myConnection.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

}
