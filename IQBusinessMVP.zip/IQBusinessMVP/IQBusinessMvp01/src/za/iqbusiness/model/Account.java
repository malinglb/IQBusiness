package za.iqbusiness.model;

import java.io.Serializable;

public class Account implements Serializable {
	

	
	private static final long serialVersionUID = 1L;
	private String email;
	private String phone;
	private String country;
	private String countryCode;
	
	
	public Account() {
		super();
		this.email = "";
		this.country = "";
		this.countryCode = "";
		this.phone = "";
	}
	public Account(String country, String countryCode, String phone, String email) {
		super();
		this.country = country;
		this.countryCode = countryCode;
		this.phone = phone;
		this.email = email;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCountryCode() {
		
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getPhone() {
		
		return phone;
	}
	public void setPhone(String phone) {
		if (phone.length() == 10 || phone.isEmpty() != true) {
			phone = this.getCountryCode() + ""+ this.phone.substring(1,10);
		}
		this.phone = phone;
	}
	
	



}
